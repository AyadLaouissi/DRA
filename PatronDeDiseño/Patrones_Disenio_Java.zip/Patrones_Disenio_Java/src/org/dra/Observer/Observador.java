package org.dra.Observer;

public interface Observador 
{ 
    void actualiza(); 
}
