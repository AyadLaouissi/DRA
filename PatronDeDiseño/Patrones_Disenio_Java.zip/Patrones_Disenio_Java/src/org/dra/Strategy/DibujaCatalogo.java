package org.dra.Strategy;

import java.util.*; 

public interface DibujaCatalogo 
{ 
    void dibuja(List<VistaVehiculo> contenido); 
}
