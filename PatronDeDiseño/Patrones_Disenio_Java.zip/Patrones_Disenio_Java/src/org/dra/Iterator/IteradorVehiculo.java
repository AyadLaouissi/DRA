package org.dra.Iterator;

public class IteradorVehiculo extends Iterador<Vehiculo> 
{

	public IteradorVehiculo() {
		super();
		// TODO Auto-generated constructor stub
	} 
}
