package org.dra.Decorator;

public interface ComponenteGraficoVehiculo 
{ 
    void visualiza(); 
}
