package org.dra.Decorator;

public class VistaVehiculo implements ComponenteGraficoVehiculo 
{ 
    public void visualiza() 
    { 
        System.out.println("Visualizacion del vehiculo"); 
    } 
}
