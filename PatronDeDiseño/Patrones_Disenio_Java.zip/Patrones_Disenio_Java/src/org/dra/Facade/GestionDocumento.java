package org.dra.Facade;

public interface GestionDocumento 
{ 
  String documento(int indice); 
} 
 
