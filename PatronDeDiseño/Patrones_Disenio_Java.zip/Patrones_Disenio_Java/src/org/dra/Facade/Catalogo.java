package org.dra.Facade;

import java.util.*; 

public interface Catalogo 
{ 
    List<String> buscaVehiculos(int precioMin, int precioMax); 
} 
 