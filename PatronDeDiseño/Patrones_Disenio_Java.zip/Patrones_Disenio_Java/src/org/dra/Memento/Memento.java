package org.dra.Memento;


public interface Memento
{
}
