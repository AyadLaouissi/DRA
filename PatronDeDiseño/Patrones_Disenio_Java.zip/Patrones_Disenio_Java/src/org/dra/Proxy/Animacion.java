package org.dra.Proxy;

public interface Animacion 
{ 
    void dibuja(); 
    void clic(); 
}
