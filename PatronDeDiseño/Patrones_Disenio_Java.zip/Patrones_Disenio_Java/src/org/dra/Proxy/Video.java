package org.dra.Proxy;

public class Video implements Animacion 
{ 
    public void clic() { } 
 
    public void dibuja() 
    { 
        System.out.println("Mostrar el video"); 
    } 
 
    public void carga() 
    { 
        System.out.println("Cargar el video"); 
    } 
 
    public void reproduce() 
    { 
        System.out.println("Reproducir el video"); 
    } 
}
