package org.dra.Bridge;

public interface FormularioImpl 
{ 
    void dibujaTexto(String texto); 
    String administraZonaIndicada(); 
}
