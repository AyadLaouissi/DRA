package org.dra.FacadePattern;

public class RobotBody 
{
	public void CreateBody() 
	{		
		System.out.println("Body Creation done");
	}
}
