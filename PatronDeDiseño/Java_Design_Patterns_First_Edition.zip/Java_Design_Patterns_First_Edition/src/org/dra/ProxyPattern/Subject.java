package org.dra.ProxyPattern;

public abstract class Subject
{
    public abstract void doSomeWork();
}
