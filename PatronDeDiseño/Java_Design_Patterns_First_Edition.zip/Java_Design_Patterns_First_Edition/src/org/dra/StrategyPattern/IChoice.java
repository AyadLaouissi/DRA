package org.dra.StrategyPattern;

public interface IChoice
{	
	void myChoice(String s1, String s2);	
}
