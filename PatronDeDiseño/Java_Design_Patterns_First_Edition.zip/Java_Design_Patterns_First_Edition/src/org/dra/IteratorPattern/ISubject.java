package org.dra.IteratorPattern;

public interface ISubject 
{
	public IIterator CreateIterator();
}
