package org.dra.TemplateMethodPattern;

public class ComputerScience extends BasicEngineering
{
	@Override
	public void SpecialPaper()
    {
	   System.out.println("Object Oriented Programming");
    }
}
