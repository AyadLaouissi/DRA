package jdp2e.facade.demo;

public class RobotColor
{
    public void setDefaultColor()
    {
    	System.out.println(" This is steel color robot.");
    }
    public void setGreenColor()
    {
    	System.out.println(" This is a green color robot.");
    }
}

