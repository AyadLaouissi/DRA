/*package jdp2e.strategy.demo;

//Additional class to explain the answer of question no 3 in the "Q&A session
public class SpecialVehicle extends Vehicle
{
	public SpecialVehicle()
	{ 
		//Initialized with AirTransport
		transportMedium= new AirTransport();
	}

	@Override
	public void showMe() 
	{
		System.out.println("I am a special vehicle who can transport both in air and water.");
	}
}*/
