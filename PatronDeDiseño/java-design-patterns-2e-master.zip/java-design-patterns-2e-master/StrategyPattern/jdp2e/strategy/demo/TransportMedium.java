package jdp2e.strategy.demo;

public interface TransportMedium 
{
	public void transport();
}
